﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    public class AttendanceRecord
    {
        public DateTime Data { get; set; }
        public string NomZach { get; set; }
        public int Chasov { get; set; }
        public int UvPrichina { get; set; }
        public int NeuvPrich { get; set; }
    }
    /// <summary>
    /// Логика взаимодействия для AttendanceWindow.xaml
    /// </summary>
    /// 
    public partial class AttendanceWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        public AttendanceWindow()
        {
            InitializeComponent();
            LoadAttendance();
        }
        private void LoadAttendance()
        {
            List<AttendanceRecord> attendanceRecords = new List<AttendanceRecord>();

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT data, nom_zach, chasov, uv_prichina, neuv_prich FROM public.posehaemost";
                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                attendanceRecords.Add(new AttendanceRecord
                                {
                                    Data = reader.GetDateTime(0),
                                    NomZach = reader.GetString(1),
                                    Chasov = reader.GetInt32(2),
                                    UvPrichina = reader.GetInt32(3),
                                    NeuvPrich = reader.GetInt32(4)
                                });
                            }
                        }
                    }
                }
                AttendanceDataGrid.ItemsSource = attendanceRecords;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddAttendanceButton_Click(object sender, RoutedEventArgs e)
        {
            AddEditAttendanceWindow addWindow = new AddEditAttendanceWindow();
            if (addWindow.ShowDialog() == true)
            {
                LoadAttendance(); // Обновляем таблицу после добавления
            }
        }

        private void EditAttendanceButton_Click(object sender, RoutedEventArgs e)
        {
            if (AttendanceDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите запись для редактирования.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            AttendanceRecord selectedRecord = (AttendanceRecord)AttendanceDataGrid.SelectedItem;
            AddEditAttendanceWindow editWindow = new AddEditAttendanceWindow(selectedRecord);
            if (editWindow.ShowDialog() == true)
            {
                LoadAttendance(); // Обновляем таблицу после редактирования
            }
        }
    }
}