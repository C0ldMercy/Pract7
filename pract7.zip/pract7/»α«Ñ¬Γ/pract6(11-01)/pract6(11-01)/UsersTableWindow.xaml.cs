﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    public class Employee
    {
        public string Fio { get; set; }
        public string Login { get; set; }
        public int Password { get; set; }
        public int Stah { get; set; }
        public string Dolzhost { get; set; }
    }
    /// <summary>
    /// Логика взаимодействия для UsersTableWindow.xaml
    /// </summary>
    public partial class UsersTableWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        private readonly string userFio;
        private readonly string currentUserDolzhost; // Поле для хранения должности текущего пользователя

        public UsersTableWindow(string userFio, string dolzhost)
        {
            InitializeComponent();
            this.userFio = userFio;
            this.currentUserDolzhost = dolzhost; // Сохраняем должность текущего пользователя
            UserFioTextBlock.Text = userFio;
            LoadUsers();
        }
        private void LoadUsers()
        {
            List<Employee> employees = new List<Employee>();

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT fio, login, password, stah, dolzhost FROM public.sotrudniki";
                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                employees.Add(new Employee
                                {
                                    Fio = reader.GetString(0),
                                    Login = reader.GetString(1),
                                    Password = reader.GetInt32(2),
                                    Stah = reader.GetInt32(3),
                                    Dolzhost = reader.GetString(4)
                                });
                            }
                        }
                    }
                }
                UsersDataGrid.ItemsSource = employees;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddEmployeeMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (currentUserDolzhost != "Admin")
            {
                MessageBox.Show("У вас нет прав для добавления сотрудников. Только администратор может выполнять эту операцию.",
                    "Ограничение доступа", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            EmployeeFormWindow addWindow = new EmployeeFormWindow();
            if (addWindow.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void EditEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentUserDolzhost != "Admin")
            {
                MessageBox.Show("У вас нет прав для редактирования данных сотрудников. Только администратор может выполнять эту операцию.",
                    "Ограничение доступа", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (UsersDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для редактирования.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Employee selectedEmployee = (Employee)UsersDataGrid.SelectedItem;
            EmployeeFormWindow editWindow = new EmployeeFormWindow(true, selectedEmployee);
            if (editWindow.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void ChangePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для смены пароля.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Employee selectedEmployee = (Employee)UsersDataGrid.SelectedItem;
            ChangePasswordWindow changePasswordWindow = new ChangePasswordWindow(selectedEmployee.Login);
            if (changePasswordWindow.ShowDialog() == true)
            {
                LoadUsers();
            }
        }
        private void ShowStudentsButton_Click(object sender, RoutedEventArgs e)
        {
            StudentsWindow studentsWindow = new StudentsWindow();
            studentsWindow.ShowDialog();
        }
        private void ShowAttendanceButton_Click(object sender, RoutedEventArgs e)
        {
            AttendanceWindow attendanceWindow = new AttendanceWindow();
            attendanceWindow.ShowDialog();
        }
        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void FireEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentUserDolzhost != "Admin")
            {
                MessageBox.Show("У вас нет прав для увольнения сотрудников. Только администратор может выполнять эту операцию.",
                    "Ограничение доступа", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (UsersDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для увольнения.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Employee selectedEmployee = (Employee)UsersDataGrid.SelectedItem;
            MessageBoxResult result = MessageBox.Show($"Вы уверены, что хотите уволить сотрудника {selectedEmployee.Fio}?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (var connection = new NpgsqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM public.sotrudniki WHERE login = @login";
                        using (var command = new NpgsqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("login", selectedEmployee.Login);
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Сотрудник успешно уволен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                                LoadUsers();
                            }
                            else
                            {
                                MessageBox.Show("Не удалось уволить сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}