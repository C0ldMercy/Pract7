﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    public class Student
    {
        public string NomZach { get; set; }
        public string Fio { get; set; }
        public string Gruppa { get; set; }
        public DateTime DataRozdenia { get; set; }
        public string Pol { get; set; }
    }
    /// <summary>
    /// Логика взаимодействия для StudentsWindow.xaml
    /// </summary>
    public partial class StudentsWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        public StudentsWindow()
        {
            InitializeComponent();
            LoadStudents();
        }
        private void LoadStudents()
        {
            List<Student> students = new List<Student>();

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT nom_zach, fio, gruppa, data_rozdenia, pol FROM public.student";
                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                students.Add(new Student
                                {
                                    NomZach = reader.GetString(0),
                                    Fio = reader.GetString(1),
                                    Gruppa = reader.GetString(2),
                                    DataRozdenia = reader.GetDateTime(3),
                                    Pol = reader.GetString(4)
                                });
                            }
                        }
                    }
                }
                StudentsDataGrid.ItemsSource = students;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddStudentButton_Click(object sender, RoutedEventArgs e)
        {
            AddEditStudentWindow addWindow = new AddEditStudentWindow();
            if (addWindow.ShowDialog() == true)
            {
                LoadStudents(); // Обновляем таблицу после добавления
            }
        }

        private void EditStudentButton_Click(object sender, RoutedEventArgs e)
        {
            if (StudentsDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите студента для редактирования.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Student selectedStudent = (Student)StudentsDataGrid.SelectedItem;
            AddEditStudentWindow editWindow = new AddEditStudentWindow(selectedStudent);
            if (editWindow.ShowDialog() == true)
            {
                LoadStudents(); // Обновляем таблицу после редактирования
            }
        }
    }
}