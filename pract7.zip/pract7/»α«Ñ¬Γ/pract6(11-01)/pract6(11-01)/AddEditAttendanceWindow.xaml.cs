﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    /// <summary>
    /// Логика взаимодействия для AddEditAttendanceWindow.xaml
    /// </summary>
    public partial class AddEditAttendanceWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        private readonly AttendanceRecord recordToEdit;
        private readonly bool isEditMode;
        public AddEditAttendanceWindow()
        {
            InitializeComponent();
            isEditMode = false;
        }
        public AddEditAttendanceWindow(AttendanceRecord record)
        {
            InitializeComponent();
            isEditMode = true;
            recordToEdit = record;
            DataTextBox.Text = record.Data.ToString("yyyy-MM-dd");
            NomZachTextBox.Text = record.NomZach; // Теперь это строка
            ChasovTextBox.Text = record.Chasov.ToString();
            UvPrichinaTextBox.Text = record.UvPrichina.ToString();
            NeuvPrichTextBox.Text = record.NeuvPrich.ToString();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Валидация данных
            if (!DateTime.TryParse(DataTextBox.Text, out DateTime data))
            {
                MessageBox.Show("Дата должна быть в формате гггг-мм-дд.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string nomZach = NomZachTextBox.Text;
            if (string.IsNullOrWhiteSpace(nomZach))
            {
                MessageBox.Show("Пожалуйста, введите номер занятия.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(ChasovTextBox.Text, out int chasov))
            {
                MessageBox.Show("Часов должно быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(UvPrichinaTextBox.Text, out int uvPrichina))
            {
                MessageBox.Show("Ув. причина должна быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(NeuvPrichTextBox.Text, out int neuvPrich))
            {
                MessageBox.Show("Неув. причина должна быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query;
                    if (isEditMode)
                    {
                        query = "UPDATE public.posehaemost SET data = @data, chasov = @chasov, uv_prichina = @uv_prichina, neuv_prich = @neuv_prich WHERE nom_zach = @nom_zach";
                    }
                    else
                    {
                        query = "INSERT INTO public.posehaemost (data, nom_zach, chasov, uv_prichina, neuv_prich) VALUES (@data, @nom_zach, @chasov, @uv_prichina, @neuv_prich)";
                    }

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("data", data);
                        command.Parameters.AddWithValue("nom_zach", nomZach); // Передаём как строку
                        command.Parameters.AddWithValue("chasov", chasov);
                        command.Parameters.AddWithValue("uv_prichina", uvPrichina);
                        command.Parameters.AddWithValue("neuv_prich", neuvPrich);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(isEditMode ? "Запись успешно обновлена." : "Запись успешно добавлена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                            this.DialogResult = true;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось сохранить данные.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}


