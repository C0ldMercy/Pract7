﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    /// <summary>
    /// Логика взаимодействия для AddEditStudentWindow.xaml
    /// </summary>
    public partial class AddEditStudentWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        private readonly Student studentToEdit;
        private readonly bool isEditMode;
        public AddEditStudentWindow()
        {
            InitializeComponent();
            isEditMode = false;
        }
        public AddEditStudentWindow(Student student)
        {
            InitializeComponent();
            isEditMode = true;
            studentToEdit = student;
            NomZachTextBox.Text = student.NomZach; // Теперь это строка
            FioTextBox.Text = student.Fio;
            GruppaTextBox.Text = student.Gruppa;
            DataRozdeniaTextBox.Text = student.DataRozdenia.ToString("yyyy-MM-dd");
            PolTextBox.Text = student.Pol;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Валидация данных
            string nomZach = NomZachTextBox.Text;
            if (string.IsNullOrWhiteSpace(nomZach))
            {
                MessageBox.Show("Пожалуйста, введите номер занятия.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string fio = FioTextBox.Text;
            if (string.IsNullOrWhiteSpace(fio))
            {
                MessageBox.Show("Пожалуйста, введите ФИО.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string gruppa = GruppaTextBox.Text;
            if (string.IsNullOrWhiteSpace(gruppa))
            {
                MessageBox.Show("Пожалуйста, введите группу.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!DateTime.TryParse(DataRozdeniaTextBox.Text, out DateTime dataRozdenia))
            {
                MessageBox.Show("Дата рождения должна быть в формате гггг-мм-дд.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string pol = PolTextBox.Text;
            if (pol != "m" && pol != "f")
            {
                MessageBox.Show("Пол должен быть 'm' или 'f'.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query;
                    if (isEditMode)
                    {
                        query = "UPDATE public.student SET fio = @fio, gruppa = @gruppa, data_rozdenia = @data_rozdenia, pol = @pol WHERE nom_zach = @nom_zach";
                    }
                    else
                    {
                        query = "INSERT INTO public.student (nom_zach, fio, gruppa, data_rozdenia, pol) VALUES (@nom_zach, @fio, @gruppa, @data_rozdenia, @pol)";
                    }

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("nom_zach", nomZach); // Передаём как строку
                        command.Parameters.AddWithValue("fio", fio);
                        command.Parameters.AddWithValue("gruppa", gruppa);
                        command.Parameters.AddWithValue("data_rozdenia", dataRozdenia);
                        command.Parameters.AddWithValue("pol", pol);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(isEditMode ? "Студент успешно обновлён." : "Студент успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                            this.DialogResult = true;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось сохранить данные.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}